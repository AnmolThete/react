import React, { useState, useEffect } from "react";
import { Bar } from "react-chartjs-2";
import axios from "axios";
import './index.css'

const Graph=() => {
   
     const [chartData, setChartData] = useState({});
     
    const aesc=(country1,country2)=>{
        if(country1.TotalConfirmed < country2.TotalConfirmed){
            return 1;
        }
        if(country1.TotalConfirmed > country2.TotalConfirmed){
            return -1;
        }
        return 0;
    }
    const chart = () => {
        let countryName = [];
        let activeCases = [];
        //let confirmed = [];
        
        axios.get('https://api.covid19api.com/summary')
        .then(res => {
            console.log(res);
            
            for(const dataObj of res.data.Countries.sort(aesc).slice(0,10)) {
                countryName.push(dataObj.Country);
                activeCases.push(parseInt(dataObj.TotalConfirmed));
                //confirmed.push(parseInt(dataObj.TotalDeaths));
            }

            setChartData({
                labels: countryName,
                datasets: [
                    {
                        label: "  Total Active ",
                        data: activeCases,
                        // color: '#1f77b4',
                        borderWidth: 22,
                        borderColor: '#f5576c',
                        fillColor: '#111111',


                    }
                ]
            });
        })
        .catch(err => {
            console.log(err);
        });
        console.log(countryName, activeCases);
    };
    
    useEffect(() => {
        chart();
    }, []);
    return (
        <div className="App">
        <h1>Bar Chart</h1>
        <div style={{width:700,margin:50}}>
        <Bar
        data={chartData}
        options={{
            responsive: true,
            title: { text: "THICKNESS SCALE", display: true },
            scales: {
                yAxes: [
                    {
                        ticks: {
                            autoSkip: true,
                            maxTicksLimit: 10,
                            beginAtZero: true
                        },
                        gridLines: {
                            display: false,
                            

                        }
                    }
                ],
                xAxes: [
                    {
                        gridLines: {
                            display: false
                        }
                    }
                ]
            }
        }}
        />
        </div>
        </div>
        );
    };
    
    export default Graph