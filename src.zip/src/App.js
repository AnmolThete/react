import logo from './logo.svg';
import './App.css';
import CovidTracker from './CovidTracker';

import Home from './Home';
import Form from './Form';
import Login from './Login';
import About from "./About";
import Error404 from './Error404';
import { Route, Switch, Router, BrowserRouter} from 'react-router-dom';
import NavBar from './Navbar';
import Graph from './Graph';
import Ex from './ex';

function App() {
  return (
    <div>  
      
      <BrowserRouter>
      <NavBar/>
      <Switch>
    <Route path="/" component={Home} exact/>
    <Route path="/about" component={About}/>
    <Route path="/login" component={Login} exact/>
    <Route path="/form" component={Form} exact/>
    <Route path="/covidtracker" component={CovidTracker} exact/>
    <Route path="/graph" component={Graph} exact/>
    <Route component={Error404}/>

    </Switch> 
    </BrowserRouter> 
        
        </div>
 
  );
}

export default App;

/*


*/
