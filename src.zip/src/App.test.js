import { render, screen } from '@testing-library/react';
import App from './App';

test('renders learn react link', () => {
  render(<App />);
  const linkElement = screen.getByText(/learn react/i);
  expect(linkElement).toBeInTheDocument();
});
/*
import React, { Children } from"react";
import Adapter  from '@wojtekmaj/enzyme-adapter-react-17';
import Enzyme ,{EnzymeAdapter, shallow,mount} from"enzyme";
import App from "./App";
import {ValueInput} from "./ValueInput";
import { findRenderedDOMComponentWithClass } from "react-dom/test-utils";

Enzyme.configure({adapter:new Adapter()});

it("Renders three Value Inputs",()=>{

    const wrapper=shallow(<App/>);
    const valCount=wrapper.find(ValueInput).length;
    expect(valCount).toEqual(3);

});
it("Fully renders three inputs", () => {
    const wrapper = mount(<App title="tester" />);
    const count = wrapper.find("input.form-control").length
    expect(count).toBe(3);
   });
   it("Shallow renders zero inputs", () => {
    const wrapper = shallow(<App />);
    const count = wrapper.find("input.form-control").length
    expect(count).toBe(0);
   })
*/