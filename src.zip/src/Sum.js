export default function Sum(a,b){
    return a+b;
}