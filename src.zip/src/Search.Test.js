import Search from "./Search"
export default function SearchTest()
describe('Checking search input'){
    it('test case-1'){

    }
}
