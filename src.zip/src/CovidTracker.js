import React, { useState, useEffect } from "react";
import axios from "axios";
import './index.css';
import Search from './Search';


export default function CovidTracker() {
    const [Countries, setCountry] = useState([]);
    const [TenCountries, setTenCountries] = useState([]);

    useEffect(() => {
        axios.get('https://api.covid19api.com/summary')
        .then(res => {
            setCountry(res.data.Countries);
            setTenCountries(res.data.Countries);
            console.log(res.data);
        }).catch(error => console.log(error));
    }, []);

    const getActiveCases = (country) => {
        return (
            country.TotalConfirmed -(country.TotalRecovered + country. TotalDeaths)
        );
    }

    const HighestCountry = () => {
        let max = Countries.reduce(
            (m, country) =>
            getActiveCases(m) > getActiveCases(country) ? m : country,
            Countries[0]
        );
    
    
    document.getElementById('t1').innerHTML ="Highest No. of cases " + "Country Name: "+ max.Country + ", Total Confirmed: "+ max.TotalConfirmed+ ", Total Deaths:" + max.TotalDeaths;
}

const LowestCountry = () => {
    let min = Countries.reduce(
        (m, country) => getActiveCases(m) < getActiveCases(country) ? m : country,
        Countries[0]
    );
    
    
    document.getElementById("t2").innerHTML = "lowest No. of cases Country Name: "+ min.Country + ", Total Confirmed: "+ min.TotalConfirmed + ", Total Deaths: "+ min.TotalDeaths;
}

const desc=(c1,c2)=>{
    if(c1.TotalConfirmed < c2.TotalConfirmed){
        return -1;
    }
    if(c1.TotalConfirmed > c2.TotalConfirmed){
        return 1;
    }
    return 0;
}

const aesc=(c1,c2)=>{
    if(c1.TotalConfirmed < c2.TotalConfirmed){
        return 1;
    }
    if(c1.TotalConfirmed > c2.TotalConfirmed){
        return -1;
    }
    return 0;
}
const getLowestTenCountries=()=>{
    var c = Countries.sort(desc).slice(0,10)
    setTenCountries(c); 
}

const getHighestTenCountries=()=>{
    var c = Countries.sort(aesc).slice(0,10)
    setTenCountries(c);
}





const tableData = TenCountries.map((c, index) => (
    <tr key={index + 1}>
      <td>{index + 1}</td>

      
          <td>{c.Country}</td>
          <td>{c.TotalConfirmed}</td>
          <td>{c.TotalRecovered}</td>
          <td>{c.TotalDeaths}</td>
          <td>
            {c.TotalConfirmed -
              (c.TotalRecovered + c.TotalDeaths)}
          </td>
        </tr>
      ))

      const AllData=()=>{
        
            setTenCountries(Countries);
            
    }
    
    
return(
    <div className="col-10">

      <button className="btn btn-primary" style={{margin:10}} onClick={AllData}>All Statistics</button>
      <button className="btn btn-danger" style={{margin:10}} onClick={getHighestTenCountries}>Top 10</button>
      <button className="btn btn-success" style={{margin:10}} onClick={getLowestTenCountries}>Bottom 10</button>
      <button className="btn btn-info" style={{margin:10}} onClick={HighestCountry}>Highest Cases</button>
      <button className="btn btn-info" style={{margin:10}} onClick={LowestCountry}>Lowest Cases</button>
      <Search data={Countries}/>
      <div id="text1"></div>
      <li id="t1"></li>
      <li id="t2"></li>
      <div id="text2"></div>
        <div id="text3"></div>
        <table className="table table-dark table-striped">
        <thead>
          <tr>
            <th>Sr. No.</th>
            <th>Country</th>
            <th>Total Confirmed</th>
            <th>Total Recovered</th>
            <th>Total Deaths</th>
            <th>Total Active Cases</th>
          </tr>
        </thead>
        <tbody>
          {tableData}
            </tbody>
          </table>
        </div>
    )
        

}





/*import React,{ useState, useEffect} from 'react';
import axios from 'axios';

export default function CovidTracker(){
    const[coviddata,setcovidData]=useState([])
    useEffect(() =>{
        axios.get('https://api.covid19api.com/summary').then(res=>{
            
            setcovidData(res.data.Countries)
            
        }).catch(err=>{console.log(err)})
        
        
    },[])
    
    const highestConfirmed = coviddata.map(item=>{
        return (
            <tr key={item.Country}>
                Highest Confirmed
                <p>Country Name : {item.Country}</p>
                <p>TotalConfirmed: {item.TotalConfirmed}</p>
                
            </tr>
        )
    });
    
    const tableData = coviddata.map(item=>{
        return (
            <tr key={item.Country}>
                <td>{item.Country}</td>
                <td>{item.TotalConfirmed}</td>
                <td>{item.TotalConfirmed-item.TotalRecovered-item.TotalDeaths}</td>
                <td>{item.TotalRecovered}</td>
                <td>{item.TotalDeaths}</td>
            </tr>
        )
    });
    return (
        <div className="row justify-content-center">
            <h1 className="row justify-content-center">Covid status </h1>
            
            <div className="col-md-8">
            <p>{highestConfirmed}</p>
                <table className="table table-bordered">
                    <thead>
                        <tr>
                            <th>Country</th>
                            <th>Confirmed</th>
                            <th>Active</th>
                            <th>Recovered</th>
                            <th>Deaths</th>
                        </tr>
                    </thead>
                    <tbody>{tableData}</tbody>
                </table>
            </div>
        </div>
    )
}*/