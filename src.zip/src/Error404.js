const Error404=()=>(
    <div className="Error404">
        <h1>
        Error404
        </h1>

    </div>
)

export default Error404