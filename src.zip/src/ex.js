import { Component } from "react";

export default class Ex extends Component{
    constructor(props){
        super(props);
        this.state = {
            num : 0,
            
        }
    }
    add =()=>{
        this.setState({num:this.state.num+10})

    }

    render(){
        return(
            <div>
                <button onClick=
                {this.add}>click me</button>
                {this.state.num}
            </div>
        )
    }
} 