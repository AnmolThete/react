import {Route, Switch} from 'react-router-dom';

import App from './App'
import Home from './Home';
import Login from './Login';
import About from './About';
import Error404 from './Error404';
import CovidTracker from './CovidTracker';
import Form from './Form';
import NavBar from './Navbar';

const AppRoutes=()=>(
    <App>
        <NavBar/>
        <Switch>
        <Route path="/" component={Home} exact/>
        <Route path="/about" component={About}/>
        <Route path="/login" component={Login} exact/>
        <Route path="/form" component={Form} exact/>
        <Route path="/covidtracker" component={CovidTracker} exact/>
        <Route component={Error404}/>

        </Switch>
    </App>
)

export default AppRoutes