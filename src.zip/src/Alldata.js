export default function Alldata(props){
    props.setTenCountries(props.Countries);
}